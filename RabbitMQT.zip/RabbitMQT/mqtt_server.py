import pika
import json
from pymongo import MongoClient
from datetime import datetime

client = MongoClient('localhost', 27017)
db = client['mqtt_db']
collection = db['data']

def callback(ch, method, properties, body):
    message = json.loads(body)
    message['timestamp'] = datetime.now()
    collection.insert_one(message)
    print(f"Received and stored message: {message}")

def consume_messages():
    connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
    channel = connection.channel()
    channel.queue_declare(queue='mqtt_queue')

    channel.basic_consume(queue='mqtt_queue', on_message_callback=callback, auto_ack=True)
    print('Waiting for messages. To exit press CTRL+C')
    channel.start_consuming()

if __name__ == '__main__':
    consume_messages()
