from flask import Flask, request, jsonify
from pymongo import MongoClient
from datetime import datetime

app = Flask(__name__)

client = MongoClient('localhost', 27017)
db = client['mqtt_db']
collection = db['mqtt_collection']

@app.route('/message_counts', methods=['GET'])
def get_message_counts():
    start_time = request.args.get('start_time')
    end_time = request.args.get('end_time')

    try:
        start_datetime = datetime.fromisoformat(start_time)
        end_datetime = datetime.fromisoformat(end_time)
    except ValueError as e:
        return jsonify({'error': str(e)}), 400

    query = {'timestamp': {'$gte': start_datetime, '$lte': end_datetime}}
    result = collection.aggregate([
        {'$match': query},
        {'$group': {'_id': '$status', 'count': {'$sum': 1}}}
    ])

    counts = {str(doc['_id']): doc['count'] for doc in result}
    return jsonify(counts)

if __name__ == '__main__':
    app.run(debug=True)
