import pika
import json
import random
import time

def publish_message():
    connection = pika.BlockingConnection(pika.ConnectionParameters('localhost'))
    channel = connection.channel()
    channel.queue_declare(queue='mqtt_queue')

    try:
        while True:
            status_value = random.randint(0, 6)
            message = {'status': status_value}
            channel.basic_publish(exchange='', routing_key='mqtt_queue', body=json.dumps(message))
            print(f"Sent message: {message}")
            time.sleep(1)
    except KeyboardInterrupt:
        connection.close()

if __name__ == '__main__':
    publish_message()
